require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data');
const read = (name) => JSON.parse(fs.readFileSync(path.join(DATA, name), 'utf8'));
const write = (name, value) => fs.writeFileSync(path.join(DATA, name), JSON.stringify(value, null, 2));
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(session({ secret: process.env.SESSION_SECRET || 'change-this-secret-before-deploy', resave: false, saveUninitialized: false, cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 } }));
app.use(express.static(path.join(__dirname, 'public')));
const requireAdmin = (req, res, next) => req.session && req.session.admin ? next() : res.status(401).json({ error: 'Faça login para continuar.' });
app.get('/lojista', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/api/config', (req, res) => res.json({ paymentProvider: 'InfinitePay', storeName: 'Pisante de Cria' }));
app.get('/api/products', (req, res) => res.json(read('products.json').filter(p => p.active !== false)));
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = process.env.ADMIN_USER || 'lojista';
  const pass = process.env.ADMIN_PASSWORD || 'troque-esta-senha';
  if (username !== user || password !== pass) return res.status(401).json({ error: 'Usuário ou senha incorretos.' });
  req.session.admin = true;
  res.json({ ok: true });
});
app.post('/api/admin/logout', requireAdmin, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/admin/me', (req, res) => res.json({ authenticated: !!(req.session && req.session.admin) }));
app.get('/api/admin/products', requireAdmin, (req, res) => res.json(read('products.json')));
app.put('/api/admin/products', requireAdmin, (req, res) => {
  if (!Array.isArray(req.body)) return res.status(400).json({ error: 'Envie uma lista de produtos.' });
  const cleaned = req.body.map(p => ({ id: String(p.id || crypto.randomUUID()), name: String(p.name || '').slice(0, 100), category: String(p.category || 'Unissex').slice(0, 40), price: Number(p.price), oldPrice: Number(p.oldPrice || 0), sizes: Array.isArray(p.sizes) ? p.sizes.map(Number).filter(Number.isFinite) : [], badge: String(p.badge || '').slice(0, 30), image: String(p.image || '').slice(0, 1000), description: String(p.description || '').slice(0, 500), active: p.active !== false }));
  if (cleaned.some(p => !p.name || !Number.isFinite(p.price) || p.price < 0)) return res.status(400).json({ error: 'Confira nomes e preços dos produtos.' });
  write('products.json', cleaned); res.json({ ok: true, products: cleaned });
});
app.get('/api/admin/orders', requireAdmin, (req, res) => res.json(read('orders.json').slice().reverse()));
app.patch('/api/admin/orders/:id', requireAdmin, (req, res) => {
  const orders = read('orders.json'); const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Pedido não encontrado.' });
  const allowed = ['separando', 'enviado', 'concluido', 'cancelado']; if (!allowed.includes(req.body.status)) return res.status(400).json({ error: 'Status inválido.' });
  order.status = req.body.status; write('orders.json', orders); res.json(order);
});
app.post('/api/checkout/infinitepay', async (req, res) => {
  try {
    if (!process.env.INFINITEPAY_HANDLE) return res.status(503).json({ error: 'Checkout ainda não configurado. O lojista precisa informar a InfiniteTag no ambiente de hospedagem.' });
    const d = req.body || {}; const cart = Array.isArray(d.cart) ? d.cart : [];
    if (!cart.length || !d.customerName || !d.customerEmail || !d.customerPhone) return res.status(400).json({ error: 'Preencha nome, e-mail, WhatsApp e adicione produtos ao carrinho.' });
    const products = read('products.json'); let totalCents = 0; const items = [];
    for (const line of cart) {
      const p = products.find(x => x.id === line.id && x.active !== false);
      const qty = Math.max(1, Math.min(10, Number(line.quantity) || 1));
      if (!p) return res.status(400).json({ error: 'Um produto do carrinho não está mais disponível.' });
      const price = Math.round(Number(p.price) * 100);
      if (!Number.isFinite(price) || price <= 0) return res.status(400).json({ error: 'Preço inválido para um dos produtos.' });
      totalCents += price * qty;
      items.push({ id: p.id, name: p.name, size: String(line.size || ''), quantity: qty, unitPrice: price / 100 });
    }
    const orderId = 'PC-' + Date.now().toString(36).toUpperCase();
    const origin = (process.env.BASE_URL || '').replace(/\/$/, '');
    const payload = { handle: process.env.INFINITEPAY_HANDLE.replace(/^\$/, ''), order_nsu: orderId,
      items: items.map(i => ({ quantity: i.quantity, price: Math.round(i.unitPrice * 100), description: `${i.name}${i.size ? ' - tamanho ' + i.size : ''}` })),
      customer: { name: String(d.customerName).slice(0,120), email: String(d.customerEmail).slice(0,200), phone_number: String(d.customerPhone).slice(0,30) } };
    if (origin) { payload.redirect_url = origin + '/pagamento-concluido'; payload.webhook_url = origin + '/api/checkout/infinitepay/webhook'; }
    if (d.address) { const m = String(d.address).match(/(\d{5})-?(\d{3})/); if (m) payload.address = { cep: m[1] + m[2], number: (String(d.address).match(/(?:,|\s)(\d{1,6})(?:,|\s|$)/)||[])[1] || 'S/N', complement: '' }; }
    const response = await fetch('https://api.checkout.infinitepay.io/links', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok || !result.url) { console.error('InfinitePay checkout error:', result); return res.status(502).json({ error: 'A InfinitePay não conseguiu criar o checkout. Confira a InfiniteTag e se o Checkout Integrado está habilitado.' }); }
    const orders = read('orders.json'); orders.push({ id: orderId, paymentProvider:'InfinitePay', paymentStatus:'pending', status:'aguardando_pagamento', createdAt:new Date().toISOString(), customer:{name:payload.customer.name,email:payload.customer.email,phone:payload.customer.phone_number,address:String(d.address||'')}, items, total:totalCents/100 }); write('orders.json',orders);
    res.json({ ok:true, orderId, checkoutUrl:result.url });
  } catch (e) { console.error(e); res.status(500).json({ error:'Erro ao iniciar o checkout. Tente novamente.' }); }
});
app.get('/pagamento-concluido', (req,res) => res.sendFile(path.join(__dirname,'public','success.html')));
app.post('/api/checkout/infinitepay/webhook', async (req,res) => {
  try {
    const body = req.body || {}; const orderId = String(body.order_nsu || body.orderNsu || '');
    if (!orderId || !process.env.INFINITEPAY_HANDLE) return res.sendStatus(400);
    const check = await fetch('https://api.checkout.infinitepay.io/payment_check', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ handle:process.env.INFINITEPAY_HANDLE.replace(/^\$/, ''), order_nsu:orderId, transaction_nsu:body.transaction_nsu || body.transactionNsu, slug:body.slug }) });
    const verified = await check.json();
    if (check.ok && verified.success) { const orders=read('orders.json'); const order=orders.find(o=>o.id===orderId); if(order){ order.paymentStatus=verified.paid?'paid':'pending'; if(verified.paid)order.status='separando'; order.paymentDetails={capture_method:verified.capture_method||null,transaction_nsu:body.transaction_nsu||null,receipt_url:body.receipt_url||null}; write('orders.json',orders); } }
    res.sendStatus(200);
  } catch(e) { console.error('InfinitePay webhook:',e.message); res.sendStatus(500); }
});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Pisante de Cria rodando em http://localhost:${PORT}`));
