# Pisante de Cria — loja virtual

Loja Node.js/Express para tênis, roupas e acessórios streetwear, com catálogo, carrinho, checkout InfinitePay e painel administrativo em `/lojista`.

## Requisitos
- Node.js 18 ou superior
- Conta InfinitePay com Checkout Integrado habilitado
- Hospedagem que mantenha o servidor Node.js ativo e permita armazenamento persistente
- HTTPS e domínio público para produção

## Rodar localmente
1. Instale Node.js 18+.
2. Entre na pasta do projeto e execute `npm install`.
3. Copie `.env.example` para `.env` e preencha as variáveis.
4. Execute `npm start` e abra `http://localhost:3000`.

## Configuração obrigatória para produção
Defina as variáveis no painel de ambiente da hospedagem (não publique o `.env`):
- `BASE_URL`: URL pública HTTPS da loja, sem barra final.
- `INFINITEPAY_HANDLE`: sua InfiniteTag sem o `$` inicial.
- `ADMIN_USER` e `ADMIN_PASSWORD`: credenciais fortes do painel.
- `SESSION_SECRET`: string aleatória longa e secreta.
- `NODE_ENV=production`

No app/site da InfinitePay, habilite **Checkout Integrado** em Vendas → Checkout → Configurações. O backend cria links via `POST https://api.checkout.infinitepay.io/links`, validando produtos e preços no servidor, e encaminha o cliente ao checkout hospedado pela InfinitePay, onde poderá pagar por Pix ou cartão conforme as opções habilitadas na conta. O redirecionamento para `/pagamento-concluido` não prova que o pagamento foi aprovado. A confirmação deve ser validada via consulta de pagamento/webhook, antes de separar ou enviar pedidos.

## Atenção antes de vender
- Esta versão é um ponto de partida para testes e precisa de teste real controlado com a conta InfinitePay antes de abrir ao público.
- O armazenamento atual de pedidos e produtos usa arquivos JSON locais. Para produção com vendas reais, prefira banco de dados persistente (ex.: PostgreSQL) e armazenamento de imagens. Não use hospedagem efêmera que apague arquivos ao reiniciar.
- A confirmação webhook precisa ser ajustada conforme o formato exato de evento fornecido pela InfinitePay à sua conta e testada ponta a ponta; não marque pedidos como pagos com base apenas nos parâmetros de redirecionamento.
- Configure política de privacidade, termos, política de troca/devolução, frete, prazos e contato da loja antes de vender.
- Nunca envie credenciais de pagamento ou senha administrativa por chat nem as coloque no frontend/repositório.

## Painel do lojista
Acesse `/lojista`. O painel usa as credenciais definidas em `ADMIN_USER` e `ADMIN_PASSWORD`. Troque os valores de exemplo antes de publicar.
